
# Aviator Predictor 4

A simple Streamlit app that simulates an Aviator game predictor using machine learning (RandomForest).

> ⚠️ **Disclaimer:** This is not a real betting tool. This is a simulation for educational purposes only.

## Features

- Random time-series based multiplier prediction.
- Uses historical data (sample included).
- Streamlit frontend to view predictions.

## Setup Instructions

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Files

- `streamlit_app.py`: Main application code.
- `requirements.txt`: Python dependencies.
- `README.md`: App documentation.
