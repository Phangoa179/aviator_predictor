
import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

class AviatorPredictor:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100)
        self.data = pd.DataFrame({
            'time': [],
            'multiplier': [],
            'cash_out': []
        })

    def update_data(self, new_data):
        new_data['time_minutes'] = new_data['time'] * 60  # convert hours to minutes
        self.data = pd.concat([self.data, new_data], ignore_index=True)

    def train_model(self):
        self.data['time_minutes'] = self.data['time'] * 60
        X = self.data[['time_minutes']]
        y = self.data['multiplier']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        self.model.fit(X_train, y_train)

    def predict(self, count=10):
        predictions = []
        for _ in range(count):
            total_minutes = np.random.randint(0, 1440)
            hour = total_minutes // 60
            minute = total_minutes % 60
            pred_multiplier = self.model.predict([[total_minutes]])[0]
            cash_out = round(pred_multiplier * 0.9, 2)
            predictions.append((f"{hour:02d}:{minute:02d}", round(pred_multiplier, 2), cash_out))
        return predictions

st.title("🎰 Aviator Predictor 4")
st.markdown("**Disclaimer:** This is a simulated predictor and not a real betting system. Use at your own risk.")

predictor = AviatorPredictor()

sample_data = pd.DataFrame({
    'time': [12, 14, 16],
    'multiplier': [2.5, 5.0, 1.8],
    'cash_out': [2.2, 4.5, 1.6]
})

predictor.update_data(sample_data)
predictor.train_model()

if st.button("Generate Predictions"):
    predictions = predictor.predict()
    df = pd.DataFrame(predictions, columns=["Time", "Multiplier", "Cash Out"])
    st.table(df)
