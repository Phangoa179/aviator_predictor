import streamlit as st
from aviator_app import predict_aviator_outcome

st.title("Aviator Predictor")

user_input = st.number_input("Enter input data (0 to 1):", min_value=0.0, max_value=1.0, step=0.01)

if st.button("Predict"):
    result = predict_aviator_outcome(user_input)
    st.write(f"Prediction: **{result}**")